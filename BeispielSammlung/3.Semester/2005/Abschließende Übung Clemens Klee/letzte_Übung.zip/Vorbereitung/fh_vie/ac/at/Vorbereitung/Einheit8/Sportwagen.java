/**
 * 
 */
package fh_vie.ac.at.Vorbereitung.Einheit8;

/**
 * Stellt einen Sportwagen mit �ltemperaturanzeige dar.
 * @author Clemens Klee<br>
 * Erstellt am 06.12.2005<br>
 * Version 1.0
 */
public class Sportwagen extends Auto {
	private float �ltemeperatur;
	
	/**
	 * Erzeugt einen neuen Sportwagen eines bestimmten Typs und
	 * setzt den Kilometerstand auf 5 km und den Tankinhalt auf 5 Liter.
	 * @param marke Die Automarke.
	 */
	public Sportwagen(String marke){
		super(marke);
	}
	
	/**
	 * Setzt die �ltemperatur.
	 * @param temp Die �ltemperatur.
	 */
	public void set�ltemperatur(float temp){
		�ltemeperatur = temp;
	}
	
	/**
	 * Liefert die �ltemperatur.
	 * @return Die �ltemperatur.
	 */
	public float get�ltemperatur(){
		return �ltemeperatur;
	}
	
}
