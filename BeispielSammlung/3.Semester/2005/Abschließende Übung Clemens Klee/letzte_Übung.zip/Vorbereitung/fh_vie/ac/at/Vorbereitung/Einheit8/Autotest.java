/**
 * 
 */
package fh_vie.ac.at.Vorbereitung.Einheit8;
import fh_vie.ac.at.Vorbereitung.*;
/**
 * @author Clemens Klee<br>
 * Erstellt am 06.12.2005<br>
 * Version 1.0
 */
public class Autotest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Auto a = new Auto("Peugeot");
		Auto b = new Auto("VW");
		a.tanken(40.5f);
		b.tanken(40);
		
		System.out.println(a.getTankinhalt());
		System.out.println(b.getTankinhalt());
		
		System.out.println(a.fahren(700, 40));
		
		System.out.println(a.getTankinhalt());
		System.out.println(a.getKilometerstand());
		
		a.print();
		b.print();
		
		In.open("Autos.dat");
		Auto c = new Auto();
		c = c.readAutofromFile();
		c.print();
		In.close();
		
		Auto d = new Sportwagen("Ferrari");
		d.print();
		Sportwagen s = (Sportwagen) d;
		s.fahren(300, 40);
		s.set�ltemperatur(90.5f);
		s.get�ltemperatur();
		
		Autoverwaltung autos = new Autoverwaltung();
		autos.createListfromFile("Autos.dat");
		
		autos.print();
		
		autos.writeListtoFile("AutosOut.dat");
		
	}

}
