/**
 * 
 */
package fh_vie.ac.at.Vorbereitung.Einheit8;
import fh_vie.ac.at.Vorbereitung.*;

/**
 * Stellt ein Auto mit Marke, Kilometerstand und Tankinhalt dar.
 * @author Clemens Klee<br>
 * Erstellt am 06.12.2005<br>
 * Version 1.0
 */
public class Auto {
	private String marke;
	private float kilometerstand;
	private float tankinhalt;
	
	/**
	 * Erzeugt ein leeres Auto-Objekt.
	 *
	 */
	public Auto(){
		
	}
	
	/**
	 * Erzeugt ein Auto eines bestimmten Typs mit einem Kilometerstand
	 * von 5 km und einem Tankinhalt von 5 Litern.
	 * @param marke Die Automarke.
	 */
	public Auto(String marke){
		setMarke(marke);
		kilometerstand = 5;
		tankinhalt = 5;
	}
	
	/**
	 * Erzeugt ein Auto-Objekt mit den �bergebenen Parametern.
	 * @param marke Die Automarke.
	 * @param kilometerstand Der Kilometerstand.
	 * @param tankinhalt Die Tankf�llung.
	 */
	public Auto(String marke,float kilometerstand,float tankinhalt){
		setMarke(marke);
		this.kilometerstand = kilometerstand;
		this.tankinhalt = tankinhalt;
	}
	
	/**
	 * Liest die Daten eines Autos aus einer Datei und liefert 
	 * ein mit diesen Daten erzeugtes Auto-Objekt zur�ck.
	 * Die Daten m�ssen im folgenden Format vorhanden sein: <br>
	 * Marke Tankinhalt Kilometerstand
	 * @return Das Auto-Objekt mit den Daten aus der Datei.
	 */
	public Auto readAutofromFile(){
		String typ = In.readWord();
		float liter = In.readFloat();
		float kilometer = In.readFloat();
		return new Auto(typ,kilometer,liter);
	}
	
	/**
	 * Schreibt die Daten eines Autos in eine Datei.
	 * Format: Marke Tankinhalt Kilometerstand
	 *
	 */
	public void writeAutotoFile(){
		Out.println(getMarke() + " "+getTankinhalt()+" "+getKilometerstand());
	}
	
	/**
	 * Setzt die Automarke.
	 * @param marke Die Automarke.
	 */
	public void setMarke(String marke){
		this.marke = marke;
	}
	
	/**
	 * Liefert die Automarke.
	 * @return Die Automarke.
	 */
	public String getMarke(){
		return marke;
	}
	
	/**
	 * Liefert den Kilometerstand.
	 * @return Der Kilometerstand.
	 */
	public float getKilometerstand(){
		return kilometerstand;
	}
	
	/**
	 * Liefert den Tankinhalt.
	 * @return Der Tankinhalt.
	 */
	public float getTankinhalt(){
		return tankinhalt;
	}
	
	/**
	 * Betankt ein Auto mit einer bestimmten Menge an Treibstoff.
	 * @param liter Die getankte Menge.
	 */
	public void tanken(float liter){
		tankinhalt = tankinhalt + liter;
	}
	
	/**
	 * Erh�ht den Kilometerstand, verringert die Tankf�llung und liefert
	 * den Verbrauch des Autos auf 100 km.
	 * @param kilometer Die gefahrenen Kilometer.
	 * @param liter Die verbrauchten Liter.
	 * @return Der Verbrauch.
	 */
	public float fahren(float kilometer,float liter){
		if (liter > tankinhalt){
			return -1;
		}
		else{
		kilometerstand = kilometerstand + kilometer;
		tankinhalt = tankinhalt - liter;
		return verbrauch(kilometer, liter);
		}
	}
	
	/**
	 * Errechnet den Verbrauch auf 100 km.
	 * @param kilometer Die gefahrenen Kilometer.
	 * @param liter Die verbrauchten Liter.
	 * @return Der Verbrauch.
	 */
	private float verbrauch(float kilometer,float liter){
		return (liter/kilometer)*100;
	}
	
	/**
	 * Gibt die Daten eines Autos am Bildschirm aus.
	 *
	 */
	public void print(){
		System.out.println("Marke: "+marke);
		System.out.println("Kilometerstand: "+kilometerstand);
		System.out.println("Tankinhalt: "+tankinhalt);
		System.out.println();
	}
}
