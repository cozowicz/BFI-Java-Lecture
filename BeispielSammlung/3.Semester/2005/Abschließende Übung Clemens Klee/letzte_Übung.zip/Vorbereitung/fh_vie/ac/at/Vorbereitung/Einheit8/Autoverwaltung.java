/**
 * 
 */
package fh_vie.ac.at.Vorbereitung.Einheit8;
import fh_vie.ac.at.Vorbereitung.*;
/**
 * Eine Verwaltungsklasse f�r die Vorf�hrwagen eines
 * Autoh�ndlers.
 * @author Clemens Klee<br>
 * Erstellt am 06.12.2005<br>
 * Version 1.0
 */
public class Autoverwaltung {
	private Auto[] autos = new Auto[100];
	private int anzAutos = 0;
	
	/**
	 * F�gt ein neues Auto in die Liste ein, wenn in dieser noch Platz ist.
	 * @param a Das Auto, das eingef�gt werden soll.
	 * @return <code>true</code>, wenn das Auto eingef�gt wurde, 
	 * sonst <code>false</code>.
	 */
	public boolean insert(Auto a){
		if (anzAutos < autos.length){
			autos[anzAutos] = a;
			anzAutos++;
			return true;
		}
		
		return false;
	}
	
	/**
	 * Erzeugt eine komplette Liste aus einer Datei.
	 * Die Datei muss das folgende Format aufweisen:<br>
	 * Automarke Tankinhalt Kilometer
	 * @param file Die Datei, aus der die Liste erzeugt werden soll.
	 * @return <code>true</code>, wenn die Liste erfolgreich erzeugt wurde,
	 * sonst <code>false</code>.
	 */
	public boolean createListfromFile(String file){
		boolean erfolg = false;
		In.open(file);
		if(In.done()){
			Auto a = new Auto();
			
			while(In.done()){
			a = a.readAutofromFile();
			erfolg = insert(a);
				if (erfolg == true){
					In.readLine();
				}
				else{
					In.close();
					return false;
				}
			}
			In.close();
			return true;
		}
		In.close();
		return false;
	}
	
	/**
	 * Schreibt eine Liste in eine Datei und erzeugt dabei das 
	 * folgende Format:
	 * Automarke Tankinhalt Kilometerstand
	 * @param file Die Datei, in die die Daten geschrieben werden sollen.
	 * @return <code>true</code>, wenn die Daten geschrieben wurden, sonst
	 * <code>false</code>.
	 */
	public boolean writeListtoFile(String file){
		Out.open(file);
		if(Out.done()){
			for(int i = 0;i<anzAutos;i++){
				autos[i].writeAutotoFile();
			}
			Out.close();
			return true;
		}
		Out.close();
		return false;	
	}
	
	/**
	 * Gibt die Liste am Bildschirm aus.
	 *
	 */
	public void print(){
		for(int i = 0; i < anzAutos;i++){
			autos[i].print();
		}
	}
}
